var AppData = /** @class */ (function () {
    function AppData() {
    }
    AppData.IS_NATIVE_APP = false;
    AppData.NATIVE_DATA = {};
    AppData.isAtHome = true;
    AppData.testStr = "test";
    AppData.isAndroidHack = true;
    return AppData;
}());
//# sourceMappingURL=AppData.js.map