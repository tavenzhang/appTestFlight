var MyPos = /** @class */ (function () {
    function MyPos(x, y) {
        this.x = x;
        this.y = y;
    }
    return MyPos;
}());
//# sourceMappingURL=MyPos.js.map